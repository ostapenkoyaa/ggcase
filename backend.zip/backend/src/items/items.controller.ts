import { Controller } from '@nestjs/common'

@Controller('items')
export class ItemsController {}
