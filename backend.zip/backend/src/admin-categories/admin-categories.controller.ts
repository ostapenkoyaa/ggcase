import { Controller } from '@nestjs/common';

@Controller('admin-categories')
export class AdminCategoriesController {}
