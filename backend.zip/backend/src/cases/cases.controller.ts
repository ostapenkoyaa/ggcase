import {Controller} from '@nestjs/common'

@Controller('cases')
export class CasesController {}
